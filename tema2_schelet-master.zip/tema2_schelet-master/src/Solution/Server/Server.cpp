#include "Server.h"

using namespace std;

/* NU MODIFICATI */
Server::Server(){}

/* NU MODIFICATI */
Server *Server::GetInstance()
{
	if (!instance)
	{
		instance = new Server;
	}

	return instance;
}

/* NU MODIFICATI */
Server::~Server()
{
	if (instance != NULL)
		instance = NULL;

	if (!__UserID__ProductsCart__.empty())
		__UserID__ProductsCart__.clear();
}

void Server::set__UserID__ProductsCart__()
{
	for(list<User *>::iterator it = usr.begin(); it != usr.end(); it++)
	{
		__UserID__ProductsCart__.insert(pair<int, ShoppingCart*>((*it)->getUserID(), new ShoppingCart()));
	}
}

list<Product *> &Server::getProductsList()
{
	return prod;
}

list<User *> &Server::getUsersList()
{
	return usr;
}

map<int, ShoppingCart *> Server::get__UserID__ProductsCart__()
{
	return __UserID__ProductsCart__;
}

bool Server::requestAddProduct(int userID, int productID, int quantity)
{
	if(quantity <= 0)
	{
		return false;
	}
	// Caut in mapa __UserID__ProductsCart__ daca exista utilizatorul cu id-ul dat ca parametru
	map<int, ShoppingCart*>::iterator it_map = __UserID__ProductsCart__.find(userID);
	if(it_map == __UserID__ProductsCart__.end())
	{
		return false;
	}

	// Parcurg lista de produse din server
	for(list<Product*>::iterator it_prod = prod.begin(); it_prod != prod.end(); it_prod++)
	{
		if((*it_prod)->getId() == productID)
		{
			if(quantity > (*it_prod)->getQuantity())
			{
				return false;
			}
			
			(*it_prod)->decreaseQuantity(quantity);
			map<int, int>::iterator it_shopping_cart = (it_map->second->getShoppingCart()).find(productID);
			if(it_shopping_cart == (it_map->second->getShoppingCart()).end())
			{
				it_map->second->addProduct(productID, quantity);
			}
			else
			{
				it_map->second->raiseQuantity(productID, quantity);
			}
			return true;
		}
	}
	return false;
}

bool Server::requestDeleteProduct(int userID, int productID, int quantity)
{
	if(quantity <= 0)
	{
		return false;
	}

	map<int, ShoppingCart*>::iterator it_map = __UserID__ProductsCart__.find(userID);
	if(it_map == __UserID__ProductsCart__.end())
	{
		return false;
	}

	map<int, int>::iterator it_prod = it_map->second->getShoppingCart().find(productID);
	if(it_prod == it_map->second->getShoppingCart().end())
	{
		return false;
	}
	int de_crescut;
	if(it_map->second->getQuantity(productID) <= quantity)
	{
		de_crescut = it_map->second->getQuantity(productID);
		it_map->second->getShoppingCart().erase(productID);
	}
	else
	{
		de_crescut = quantity;
		it_map->second->lowerQuantity(productID, quantity);
	}

	for(list<Product*>::iterator it_produs = prod.begin(); it_produs != prod.end(); it_produs++)
	{
		(*it_produs)->increaseQuantity(de_crescut);
	}

	return true;
}

/* NU MODIFICATI */
void Server::populateProducts(const json &input)
{
	prod = ObjectFactory::getProductList(input["shoppingCart"]);
}

/* NU MODIFICATI */
void Server::populateUsers(const json &input)
{
	usr = ObjectFactory::getUserList(input["useri"]);
}