#include "LRUCache.h"
#include <algorithm>

using namespace std;

LRUCache::LRUCache(int capacity)
{
	this->capacity = capacity;
	lru = vector<int>(capacity);
	size = 0;
}

vector<int> LRUCache::processRequests(vector<int> requestsNo)
{
	bool gasit;
	// Parcurg vectorul de request-uri
	for(unsigned int i=0; i<requestsNo.size(); i++)
	{
		gasit = false;
		// Parcurg vectorul din cache
		for(unsigned int j=0; j<size; j++)
		{
			if(requestsNo[i] == lru[j])
			{
				for(unsigned int k=j; k>0; k--)  // deplasez la dreapta pana in pozitia din lru unde am gasit valoarea
				{
					lru[k] = lru[k-1];
				}
				lru[0] = requestsNo[i];
				gasit = true;
				break;
			}
		}

		if(!gasit)
		{
			if(size < capacity)
			{
				for(unsigned int k=size; k>0; k--)
				{
					lru[k] = lru[k-1];
				}
				lru[0] = requestsNo[i];
				size++;
			}
			else
			{
				for(unsigned int k=size-1; k>0; k--)
				{
					lru[k] = lru[k-1];
				}
				lru[0] = requestsNo[i];
			}
		}
	}

	return lru;
}

int LRUCache::getCapacity()
{
	return capacity;
}

int LRUCache::getSize()
{
	return size;
}

vector<int> LRUCache::getLRU()
{
	return lru;
}

int LRUCache::getLRUCapacity()
{
	return lru.capacity();
}

void LRUCache::setCapacity(int capacity)
{
	this->capacity = capacity;
}

void LRUCache::setLRU(vector<int> aux)
{
	lru = aux;
}
