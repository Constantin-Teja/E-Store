#include "QuerySolver.h"

using namespace std;

/* NU MODIFICATI */
QuerySolver::QuerySolver() 
{
  server = Server::GetInstance();
}

/* NU MODIFICATI */
QuerySolver::~QuerySolver()
{
  if (server != nullptr) 
  {
    server = nullptr;
  }
}

list<Product*> QuerySolver::Query_3a(){
  list<Product*> produse = server->getProductsList(); // lista de produse din server
  list<Product*> reduse;	// lista de produse reduse. Lista ce va fi returnata

  // Parcurg lista de produse din server
  for(list<Product*>::iterator it = produse.begin(); it != produse.end(); it++)
  {
    // Testez daca produsul este si redus si espressor
    if(((*it)->getProductType() == "redus") && ((*it)->getCategory() == "espressor"))
    {
      // Adaug produsul in lista de produse ce va fi returnata
      reduse.push_back(*it);
    }
  }

  return reduse;
}

list<User*> QuerySolver::Query_3b(){
  list<User*> utilizatori = server->getUsersList(); // lista de utilizatori din server
  list<User*> basic;  // lista de utilizatori care va fi returnata

  // Parcurg lista de utilizatori din server
  for(list<User*>::iterator it = utilizatori.begin(); it != utilizatori.end(); it++)
  {
    // Testez daca utilizatorul este nonpremium si are costul de transport sub 11.5 lei
    if(((*it)->getUserType() == "basic") && ((*it)->getTransportCost() <= 11.5))
    {
      // Adaug utilizatorul in lista de utilizatori ce va fi returnata
      basic.push_back(*it);
    }
  }

  return basic;
}

list<Product*> QuerySolver::Query_3c(){
  list<Product*> produse = server->getProductsList(); // lista de produse din server
  list<Product*> resigilate;  // lista de produse ce va fi returnata

  // Parcurg lista de produse din server
  for(list<Product*>::iterator it = produse.begin(); it != produse.end(); it++)
  {
    // Testez daca produsul e resigilat
    if(((*it)->getProductType() == "resigilat"))
    {
      // Testez daca motivul returnarii produsului este lipsa accesoriilor
      if((dynamic_cast<ResealedProduct*>(*it))->getReason() == "lipsa_accesorii")
      {
        // Adaug produsul in lista de produse care va fi returnata
        resigilate.push_back(*it);
      }
    }
  }
  // Sortez lista folosind ca functie de comparatie comparePrices din clasa Utility
  resigilate.sort(Utility::comparePrices);

  return resigilate;
}

list<Product*> QuerySolver::Query_3d(){
  list<Product*> produse = server->getProductsList(); // lista de produse din server
  list<Product*> alimentare;  // lista de produse ce va fi returnata

  // Parcurg lista de produse din server
  for(list<Product*>::iterator it = produse.begin(); it != produse.end(); it++)
  {
    // Testez daca produsul este alimentar
    if((*it)->getProductType() == "alimentar")
    {
      // Adaug produsul in lista de produse ce va fi returnata
      alimentare.push_back(*it);
    }
  }
  // Sortez lista de produse folosind metoda compareProducts din clasa Utility
  alimentare.sort(Utility::compareProducts);

  return alimentare;
}

list<User*> QuerySolver::Query_3e(){
  list<User*> users = server->getUsersList(); // lista de utilizatori din server
  list<User*> utilizatori;  // lista de utilizatori ce va fi returnata
  map<string, int> judete;  // map de judete
  
  bool gasit;
  // Parcurg lista de utilizatori din server
  for(list<User*>::iterator it = users.begin(); it != users.end(); it++)
  {
    gasit = false;
    // Parcurg mapa de judete
    for(map<string, int>::iterator i = judete.begin(); i != judete.end(); i++)
    {
      if(i->first == ((*it)->getDeliveryData()).getCounty())
      {
        (i->second)++;
        gasit = true;
        break;
      }
    }
    if(!gasit)
    {
      judete.insert(pair<string, int>(((*it)->getDeliveryData()).getCounty(), 1));
    }
  }

  int max = 0;  // stochez numarul maxim de utilizatori dintr-un judet
  string jud_max; // stochez judetul cu cel mai multi utilizatori
  // Parcurg mapa de judete si determinul judetul cu cei mai multi utilizatori
  for(map<string, int>::iterator i = judete.begin(); i != judete.end(); i++)
  {
    if(i->second > max)
    {
      max = i->second;
      jud_max = i->first;
    }
  }

  /* Parcurg lista de utilizatori din server si daca acestia stau la
  casa in judetul cu cei mai multi utilizatori, ii adauga in lista de
  utilizatori ce va fi returnata*/
  for(list<User*>::iterator it = users.begin(); it != users.end(); it++)
  {
    if((((*it)->getDeliveryData()).getApartment() == 0) && (((*it)->getDeliveryData()).getBlock() == "-") && (((*it)->getDeliveryData()).getCounty() == jud_max) && ((((*it)->getBillingData()).getApartment() == 0) && (((*it)->getBillingData()).getBlock() == "-")))
    {
      utilizatori.push_back(*it);
    }
  }

  // Sortez lista de utilizatori ce va fi returnata
  utilizatori.sort(Utility::compareUsers);

  return utilizatori;
}

list<User*> QuerySolver::Query_3f()
{
  list<User*> users = server->getUsersList(); // lista de utilizatori din server
  list<User*> utilizatori;  // lista de utilizatori ce va fi returnata
  list<Product*> products = server->getProductsList();  // lista de produse din server

  bool este; // pentru a nu fi nevoie sa caute in toata lista de discounturi
  for(list<User*>::iterator it = users.begin(); it != users.end(); it++)
  {
    if((*it)->getUserType() == "premium")
    {
      este = false;
      PremiumUser* user = dynamic_cast<PremiumUser*>(*it);

      for(map<int, int>::iterator i = user->getDiscounts().begin(); i != (user)->getDiscounts().end(); i++)
      {
        int id = i->first;
        while(id >= 100) {id /= 10;} // Pentru a nu fi nevoie sa caut in lista de produse daca produsul respectiv nu e nici macar telefon sau imprimanta
        if(id/10 != 1)
        {
          id = id%10;
          if((id == 1) || (id == 6))
          {
            for(list<Product*>::iterator itt = products.begin(); itt != products.end(); itt++)
            {
              if(i->first == (*itt)->getId())
              {
                utilizatori.push_back(*it);
                este = true;
                break;
              }
            }
            if(este) {break;}
          }
        }
      }
    }
  }

  return utilizatori;
}
