#include "utility.h"

/* Compara produsele in functie de Nume, daca sunt egale in functie de tara si daca 
si tarile sunt aceleasi in functie de pret per Kg*/
bool Utility::compareProducts(Product *prod1, Product *prod2)
{
  FoodProduct *f1 = dynamic_cast<FoodProduct*>(prod1);
  FoodProduct *f2 = dynamic_cast<FoodProduct*>(prod2);

  if(f1->getName() < f2->getName()) {return true;}
  else if(f1->getName() > f2->getName()) {return false;}
  else
  {
  	if(f1->getCountryOfOrigin() < f2->getCountryOfOrigin()) {return true;}
  	else if(f1->getCountryOfOrigin() > f2->getCountryOfOrigin()) {return false;}
  	else
  	{
  		if(f1->getLeiPerKg() < f2->getLeiPerKg()) {return true;}
  		else {return false;}
  	}
  }
 
  return false;
}

// Compara produsele in functie de pret
bool Utility::comparePrices(Product *prod1, Product *prod2)
{
	NonFoodProduct *f1 = dynamic_cast<NonFoodProduct*>(prod1);
	NonFoodProduct *f2 = dynamic_cast<NonFoodProduct*>(prod2);

	if(f1->getPrice() < f2->getPrice()) {return true;}
	else {return false;}
	return false;
}

// Compara utilizatorii in functie de id
bool Utility::compareUsers(User *usr1, User *usr2)
{
	if(usr1->getUserID() < usr2->getUserID()) {return true;}
	else {return false;}
	return false;
}
